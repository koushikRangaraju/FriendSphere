import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Brain, Users, Info, Mail } from 'lucide-react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Recommendations from './pages/Recommendations';
import HowItWorks from './pages/HowItWorks';
import About from './pages/About';

function App() {
  const navItems = [
    { path: '/', label: 'Home', icon: Users },
    { path: '/recommendations', label: 'Find Friends', icon: Brain },
    { path: '/how-it-works', label: 'How It Works', icon: Info },
    { path: '/about', label: 'About', icon: Mail },
  ];

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <Navbar items={navItems} />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="/how-it-works" element={<HowItWorks />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;