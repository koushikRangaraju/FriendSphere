import React, { useState } from 'react';
import { User, Heart, Send, Brain } from 'lucide-react';

const interests = [
  'Gaming', 'Reading', 'Music', 'Sports', 'Travel', 
  'Cooking', 'Art', 'Technology', 'Movies', 'Photography'
];

const traits = [
  'Adventurous', 'Creative', 'Intellectual', 'Athletic',
  'Social', 'Ambitious', 'Empathetic', 'Humorous'
];

const mockFriends = [
  {
    id: '1',
    name: 'Alex Chen',
    age: 28,
    gender: 'Non-binary',
    interests: ['Gaming', 'Technology', 'Music'],
    personalityType: 'Ambivert',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200&h=200',
    compatibilityScore: 95
  },
  {
    id: '2',
    name: 'Jordan Taylor',
    age: 25,
    gender: 'Female',
    interests: ['Art', 'Travel', 'Photography'],
    personalityType: 'Extrovert',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200&h=200',
    compatibilityScore: 88
  }
];

const Recommendations = () => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    selectedInterests: [] as string[],
    personalityType: '',
    preferredTraits: [] as string[]
  });
  const [showResults, setShowResults] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowResults(true);
  };

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      selectedInterests: prev.selectedInterests.includes(interest)
        ? prev.selectedInterests.filter(i => i !== interest)
        : [...prev.selectedInterests, interest]
    }));
  };

  const handleTraitToggle = (trait: string) => {
    setFormData(prev => ({
      ...prev,
      preferredTraits: prev.preferredTraits.includes(trait)
        ? prev.preferredTraits.filter(t => t !== trait)
        : [...prev.preferredTraits, trait]
    }));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900">Find Your Friends</h1>
        <p className="text-xl text-gray-600">
          Let our AI find your perfect friend matches
        </p>
      </section>

      {!showResults ? (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-lg space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            <div>
              <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">
                Age
              </label>
              <input
                type="number"
                id="age"
                value={formData.age}
                onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">
              Gender
            </label>
            <select
              id="gender"
              value={formData.gender}
              onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
              className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Select gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Non-binary">Non-binary</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Interests
            </label>
            <div className="flex flex-wrap gap-2">
              {interests.map(interest => (
                <button
                  key={interest}
                  type="button"
                  onClick={() => handleInterestToggle(interest)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                    formData.selectedInterests.includes(interest)
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {interest}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="personalityType" className="block text-sm font-medium text-gray-700 mb-1">
              Personality Type
            </label>
            <select
              id="personalityType"
              value={formData.personalityType}
              onChange={(e) => setFormData(prev => ({ ...prev, personalityType: e.target.value }))}
              className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Select personality type</option>
              <option value="Introvert">Introvert</option>
              <option value="Extrovert">Extrovert</option>
              <option value="Ambivert">Ambivert</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Preferred Friend Traits
            </label>
            <div className="flex flex-wrap gap-2">
              {traits.map(trait => (
                <button
                  key={trait}
                  type="button"
                  onClick={() => handleTraitToggle(trait)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                    formData.preferredTraits.includes(trait)
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {trait}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition flex items-center justify-center space-x-2"
          >
            <Brain className="w-5 h-5" />
            <span>Find My Matches</span>
          </button>
        </form>
      ) : (
        <section className="space-y-8">
          <div className="bg-blue-50 p-6 rounded-lg text-center animate-pulse">
            <p className="text-blue-800 font-medium">
              AI is analyzing your profile and finding your best matches...
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {mockFriends.map(friend => (
              <div key={friend.id} className="bg-white p-6 rounded-lg shadow-lg">
                <div className="flex items-start space-x-4">
                  <img
                    src={friend.avatar}
                    alt={friend.name}
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-semibold">{friend.name}</h3>
                      <span className="bg-green-100 text-green-800 text-sm font-medium px-2.5 py-0.5 rounded-full">
                        {friend.compatibilityScore}% Match
                      </span>
                    </div>
                    <p className="text-gray-600">
                      {friend.age} • {friend.gender} • {friend.personalityType}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {friend.interests.map(interest => (
                        <span
                          key={interest}
                          className="bg-blue-50 text-blue-700 text-sm px-2 py-1 rounded-full"
                        >
                          {interest}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex justify-end space-x-2">
                  <button className="flex items-center space-x-1 px-3 py-1 rounded-md text-gray-600 hover:bg-gray-100">
                    <Heart className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                  <button className="flex items-center space-x-1 px-3 py-1 rounded-md bg-blue-600 text-white hover:bg-blue-700">
                    <Send className="w-4 h-4" />
                    <span>Connect</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default Recommendations;