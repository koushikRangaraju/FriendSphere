import React from 'react';
import { Brain, Users, Sparkles, ArrowRight } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: Users,
      title: "Share Your Preferences",
      description: "Tell us about yourself, your interests, and what you're looking for in friends.",
      color: "blue"
    },
    {
      icon: Brain,
      title: "AI Analysis",
      description: "Our AI analyzes your profile using collaborative filtering and personality matching algorithms.",
      color: "purple"
    },
    {
      icon: Sparkles,
      title: "Get Matched",
      description: "Receive personalized friend recommendations based on compatibility scores.",
      color: "pink"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-16">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900">How FriendSphere Works</h1>
        <p className="text-xl text-gray-600">
          Using advanced AI to create meaningful connections
        </p>
      </section>

      <section className="relative">
        <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gray-200 -translate-y-1/2 hidden md:block" />
        <div className="grid md:grid-cols-3 gap-8 relative">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="relative">
                <div className="bg-white p-6 rounded-lg shadow-lg text-center space-y-4">
                  <div className={`bg-${step.color}-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto`}>
                    <Icon className={`w-8 h-8 text-${step.color}-600`} />
                  </div>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/2 z-10">
                    <ArrowRight className="w-6 h-6 text-gray-400" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      <section className="bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold mb-6">Our AI Technology</h2>
        <div className="space-y-4">
          <p className="text-gray-600">
            We use advanced AI models similar to what Netflix and Spotify use for recommendations. 
            Our system considers multiple factors:
          </p>
          <ul className="list-disc list-inside space-y-2 text-gray-600 ml-4">
            <li>Interest matching using natural language processing</li>
            <li>Personality compatibility through behavioral analysis</li>
            <li>Activity patterns and social preferences</li>
            <li>Mutual connections and shared experiences</li>
          </ul>
          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <p className="text-blue-800 font-medium">
              Fun fact: Our AI processes over 50 different data points to find your perfect friend matches! 
              Just like how Netflix knows what shows you'll love, we know which people you'll click with. 😊
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HowItWorks;