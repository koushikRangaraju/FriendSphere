import React from 'react';
import { Link } from 'react-router-dom';
import { Brain, Users, Sparkles } from 'lucide-react';

const Home = () => {
  const testimonials = [
    {
      name: "Sarah K.",
      text: "FriendSphere's AI matched me with people who share my passion for photography. I've made genuine connections!",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      name: "Michael R.",
      text: "The personality matching is incredible. Found my gaming squad through this platform!",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100&h=100"
    }
  ];

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="text-center space-y-8 pt-16 px-4">
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-100 to-purple-100 rounded-3xl transform -rotate-1"></div>
          <div className="relative bg-white p-12 rounded-3xl shadow-xl">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Discover Friends Who Match Your Vibe
              <span className="block text-blue-600 mt-2">Powered by AI</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Using advanced AI algorithms, we connect you with like-minded individuals who share your interests, values, and personality traits.
            </p>
            <div className="flex justify-center gap-4 mt-8">
              <Link
                to="/recommendations"
                className="px-8 py-3 bg-blue-600 text-white rounded-full font-semibold hover:bg-blue-700 transition transform hover:scale-105"
              >
                Get Started
              </Link>
              <Link
                to="/how-it-works"
                className="px-8 py-3 bg-white text-blue-600 rounded-full font-semibold border-2 border-blue-600 hover:bg-blue-50 transition transform hover:scale-105"
              >
                See How It Works
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto px-4">
        <div className="bg-white p-8 rounded-xl shadow-lg transform hover:-translate-y-1 transition duration-300">
          <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
            <Brain className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-xl font-semibold text-center mb-4">AI-Powered Matching</h3>
          <p className="text-gray-600 text-center">Our advanced algorithms analyze your interests and personality to find perfect matches.</p>
        </div>
        <div className="bg-white p-8 rounded-xl shadow-lg transform hover:-translate-y-1 transition duration-300">
          <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
            <Users className="w-8 h-8 text-purple-600" />
          </div>
          <h3 className="text-xl font-semibold text-center mb-4">Genuine Connections</h3>
          <p className="text-gray-600 text-center">Connect with people who truly understand and share your interests.</p>
        </div>
        <div className="bg-white p-8 rounded-xl shadow-lg transform hover:-translate-y-1 transition duration-300">
          <div className="bg-pink-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-8 h-8 text-pink-600" />
          </div>
          <h3 className="text-xl font-semibold text-center mb-4">Smart Recommendations</h3>
          <p className="text-gray-600 text-center">Get personalized friend suggestions based on your unique preferences.</p>
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">What Our Users Say</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-lg transform hover:-translate-y-1 transition duration-300">
              <div className="flex items-center space-x-4 mb-6">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full border-4 border-blue-100"
                />
                <h3 className="font-semibold text-xl">{testimonial.name}</h3>
              </div>
              <p className="text-gray-600 italic text-lg leading-relaxed">"{testimonial.text}"</p>
              <div className="mt-4 flex justify-end">
                <div className="flex text-yellow-400">
                  {"★".repeat(5)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Find Your Circle?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of users who've found their perfect friend match!</p>
          <Link
            to="/recommendations"
            className="inline-block px-8 py-3 bg-white text-blue-600 rounded-full font-semibold hover:bg-blue-50 transition transform hover:scale-105"
          >
            Start Matching Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;