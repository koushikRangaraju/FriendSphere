export interface Friend {
  id: string;
  name: string;
  age: number;
  gender: string;
  interests: string[];
  personalityType: 'Introvert' | 'Extrovert' | 'Ambivert';
  avatar: string;
  compatibilityScore: number;
}

export interface UserPreferences {
  name: string;
  age: number;
  gender: string;
  interests: string[];
  personalityType: 'Introvert' | 'Extrovert' | 'Ambivert';
  preferredTraits: string[];
}